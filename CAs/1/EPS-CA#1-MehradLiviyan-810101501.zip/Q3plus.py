import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import binom
from scipy.stats import poisson
from scipy.stats import norm
import math
NUMBEROFUNIFORMSAMPLES = 1000
NUMBEROFPOISSONSAMPLES = 1000
NUMBEROFEXPONENTIALSAMPLES = 1000
NUMBEROFNORMALLSAMPLES = 1000
MINSCORE = 0
MAXSCORE = 100
INPUTRANGE = range(MINSCORE , MAXSCORE+1)
PROBABILITY = 0.75

def makeUniformSamples():
    return np.random.uniform(0 , 100 , NUMBEROFUNIFORMSAMPLES)

def makePoissonSamples():
    return np.random.poisson(PROBABILITY*MAXSCORE,NUMBEROFPOISSONSAMPLES)

def makeExponentialSamples():
    return np.random.exponential(math.sqrt(PROBABILITY*MAXSCORE*(1-PROBABILITY)) , NUMBEROFEXPONENTIALSAMPLES)

def main():
    uniformSamples = makeUniformSamples()
    poissonSamples = makePoissonSamples()
    exponentialSamples = makeExponentialSamples()
    allSamples = uniformSamples + poissonSamples + exponentialSamples
    normallSamples = np.random.normal(np.mean(allSamples) , np.std(allSamples) , NUMBEROFNORMALLSAMPLES)
    plt.hist(allSamples , density=True , bins=100 , edgecolor='black')
    plt.hist(normallSamples , density=True , bins=100 , edgecolor='green')
    plt.show()
    
    
main()