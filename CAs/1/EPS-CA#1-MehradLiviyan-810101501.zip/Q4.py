import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import binom
from scipy.stats import poisson
from scipy.stats import norm
import math


MAXPROBABILITY = 100
MINPROBABILITY = 0
RANGEPROBABILITY = range(MINPROBABILITY , MAXPROBABILITY + 1)
NUMBEROFACCIDENTS = 7072
INPUTRANGE = range(NUMBEROFACCIDENTS + 1)
PROBABILITY = 0.45
VARIANCE = PROBABILITY * (1-PROBABILITY) * NUMBEROFACCIDENTS
EXPECTION = PROBABILITY * NUMBEROFACCIDENTS
NUMBEROFSAMPLES = 10000
def makeBinomialTable():
    xRange = np.array(INPUTRANGE)
    samples = np.random.binomial(NUMBEROFACCIDENTS , PROBABILITY , NUMBEROFSAMPLES)
    yRange = [(samples==x).sum()/NUMBEROFSAMPLES for x in INPUTRANGE]
    yRange = np.array(yRange)
    plt.plot(xRange , yRange)
    
def makePoissonTable():
    xRange = np.array(INPUTRANGE)
    yRange = np.array([poisson.pmf(x,NUMBEROFACCIDENTS*PROBABILITY , loc=0) for x in INPUTRANGE])
    plt.plot(xRange , yRange)

def makeNormalTable():
    xRange = np.array(INPUTRANGE)
    yRange = np.array([norm.pdf(x,loc=(NUMBEROFACCIDENTS*PROBABILITY) , scale=math.sqrt(NUMBEROFACCIDENTS*PROBABILITY*(1-PROBABILITY))) for x in INPUTRANGE])
    plt.plot(xRange , yRange)

def main():
    makeBinomialTable()
    makePoissonTable()
    makeNormalTable()
    plt.show()
        
        
main()