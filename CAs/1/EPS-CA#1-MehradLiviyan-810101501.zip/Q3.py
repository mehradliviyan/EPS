import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import binom
from scipy.stats import poisson
from scipy.stats import norm

MINSCORE = 0
MAXSCORE = 160
SCORERANGE = range(MINSCORE , MAXSCORE)
LOC = 80
SCALE = 12
UPPROBABILITY = 0.1
MAXPROBABILITY = 1
MINPROBABILITY = 0
Q2 = 0.5
Q3 = 0.75
INCHARCK2AND3 = lambda x : x >= Q2 and x <= Q3
INPERCENTAGE1ANDPERCENTGE2 = lambda x : x > PERCENTAGE1 and x < PERCENTAGE2
PERCENTAGE1 = 0.8
PERCENTAGE2 = 0.9
SCORE1 = 80
SCORE2 = 90

def minOf10Percent():
    result = norm.ppf(PERCENTAGE2 , loc=LOC , scale = SCALE)
    print('min score we need to be in high 10% :' ,  result)


def betweenQ2andQ3():
    result1 = norm.ppf(Q2 , loc=LOC , scale = SCALE)
    result2 = norm.ppf(Q3 , loc=LOC , scale = SCALE)
    print('needed period score to be between Q2 and Q3 :' ,  '[' , result1 , ',' , result2 , ']')

def between2Score():
    result1 = norm.cdf(SCORE1 , loc=LOC , scale = SCALE)
    result2 = norm.cdf(SCORE2 , loc=LOC , scale = SCALE)
    print('probability of score be between 80 and 90 :' , '[' , result1 , ',' , result2 , ']' ,'is equal to ', result2-result1)
    result1 = norm.cdf(SCORE1-0.5 , loc=LOC , scale = SCALE)
    result2 = norm.cdf(SCORE2+0.5 , loc=LOC , scale = SCALE)
    print('probability of score be between 79.5 and 90.5 :' , '[' , result1 , ',' , result2 , ']' ,'is equal to ', result2-result1)
    
    
def showCDF():
    xRange = SCORERANGE
    yRange = np.array([norm.cdf(x , loc=LOC , scale=SCALE) for x in SCORERANGE])
    plt.plot(xRange , yRange)
    plt.show()


def showPDF():
    xRange = SCORERANGE
    yRange = np.array([norm.pdf(x , loc=LOC , scale=SCALE) for x in SCORERANGE])
    plt.plot(xRange , yRange)
    plt.show()
    
    
def main():
    minOf10Percent()
    betweenQ2andQ3()
    between2Score()
    showCDF()
    showPDF()

    
main()