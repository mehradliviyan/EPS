import numpy as np
from matplotlib import pyplot as plt

MAXPROBABILITY = 100
MINPROBABILITY = 0
RANGEPROBABILITY = range(MINPROBABILITY , MAXPROBABILITY + 1)
NUMBEROFREPEAT = 500
NUMBEROFSAMPLES = 5000
SUCCES = 1
FAIL = 0
INPERCENT = 0.01


def useBernoulli(p , numberOfRepeat = 1 , numberOfSamples = 1):
    datas = np.array(np.random.choice([SUCCES , FAIL] , p=[p , 1-p]  , size=numberOfRepeat*numberOfSamples)).reshape(numberOfSamples , numberOfRepeat)
    return datas.sum(axis=1)

def makeExpectionBernoulliTable():
    xRange = np.array(RANGEPROBABILITY)
    yRange = [useBernoulli(p*INPERCENT , NUMBEROFREPEAT , NUMBEROFSAMPLES).sum()/NUMBEROFSAMPLES for p in RANGEPROBABILITY]
    yRange = np.array(yRange)
    plt.plot(xRange , yRange)

def makeVarianceBernoulliTable():
    xRange = np.array(RANGEPROBABILITY)
    yRange = [np.var(useBernoulli(p*INPERCENT , NUMBEROFREPEAT , NUMBEROFSAMPLES)) for p in RANGEPROBABILITY]
    yRange = np.array(yRange)
    plt.plot(xRange , yRange)
    
    
def makeVarianceBinomialTable():
    xRange = np.array(RANGEPROBABILITY)
    yRange = np.array([(p*INPERCENT *NUMBEROFREPEAT*(1-p*INPERCENT)) for p in RANGEPROBABILITY])
    plt.plot(xRange , yRange)
    
def makeExpectionBinomialTable():
    xRange = np.array(RANGEPROBABILITY)
    yRange = np.array([(p*INPERCENT *NUMBEROFREPEAT) for p in RANGEPROBABILITY])
    plt.plot(xRange , yRange)    
    
def showVarianceTable():
    makeVarianceBernoulliTable()
    makeVarianceBinomialTable()
    plt.show()

def showExpectionTable():
    makeExpectionBernoulliTable()
    makeExpectionBinomialTable()
    plt.show()



def main():
    print('variance tables :')
    showVarianceTable()
    print('expection table :')
    showExpectionTable()
        
        
        
main()