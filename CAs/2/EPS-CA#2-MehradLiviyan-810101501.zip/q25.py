import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import binom
import sympy
from functools import reduce
s = sympy.symbols('s')
N = 10
i = sympy.symbols('i')
xiList = []
p = (N-i+1)/N
for k in range(1 , N + 1):
    xiList.append((p.subs({i:k}) * sympy.exp(s))/(1-((1-p.subs({i:k}))*sympy.exp(s))))
fiX = reduce(lambda x,y : x*y , xiList)
fiXMoshtagh = sympy.diff(fiX , s)
print(fiXMoshtagh.subs({s:0}))
print(fiXMoshtagh.subs({s:0}).evalf())