import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import poisson
METROLANDA = 3.5316
BRTLANDA = 2.0636
XRANGE = np.array(range(15))
file = pd.read_csv('./Tarbiat.csv')
LISTOFMETRO = np.array(file['metro'])
LISTOFBRT = np.array(file['BRT'])
plt.hist(LISTOFMETRO , color='red' , density=True)
yRange = np.array([poisson.pmf(x , METROLANDA , loc=0) for x in XRANGE])
plt.plot(XRANGE , yRange)
plt.show()
plt.hist(LISTOFBRT , color='blue' , density=True)
yRange = np.array([poisson.pmf(x , BRTLANDA , loc=0) for x in XRANGE])
plt.plot(XRANGE , yRange , color='red')
plt.show()
