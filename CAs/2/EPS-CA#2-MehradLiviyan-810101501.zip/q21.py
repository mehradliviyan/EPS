import numpy as np
def monteCarlo(n , k):
    goal = set([x for x in range(n)])
    answers = []
    for i in range(k):
        count = 0
        temp = set()
        while(goal != temp):
            count = count + 1
            temp.add(np.random.choice(list(goal)))
        answers.append(count)
    return np.mean(answers)
        
        
print('n = 10 and k = 10 :' , monteCarlo(10 , 10))
print('n = 10 and k = 100 :' , monteCarlo(10 , 100))
print('n = 10 and k = 1000 :' , monteCarlo(10 , 1000))