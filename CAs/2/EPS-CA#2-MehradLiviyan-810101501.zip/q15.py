import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import poisson
METROLANDA = 3.516
BRTLANDA = 2.0636
XRANGE = np.array(range(15))
file = pd.read_csv('./Tarbiat.csv')
ZLIST = np.array(file['metro']) + np.array(file['BRT'])
plt.hist(ZLIST , color='green' , density=True)
yRange = np.array([poisson.pmf(x , METROLANDA+BRTLANDA , loc=0) for x in XRANGE])
plt.plot(XRANGE , yRange , color='pink')
plt.show()
print('z mean : ' , np.mean(ZLIST))