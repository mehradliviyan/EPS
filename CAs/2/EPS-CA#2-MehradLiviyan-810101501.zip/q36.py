import pandas as pd
import numpy as np
PLABEL8 = 0.5
PLABEL9 = 0.5

df = pd.read_csv('digits.csv')
num201 = df.iloc[200]
num202 = df.iloc[201]
# df.drop([200 , 201] , axis=0 , inplace=True)
label = pd.DataFrame(df['label'])
df[df < 128] = 0
df[df >= 128] = 1
df['label'] = label
num8 = []
num9 = []
for i in range(784):
    num8.append(np.mean(df.loc[df['label'] == 8]['pixel' + str(i)]))
    num9.append(np.mean(df.loc[df['label'] == 9]['pixel' + str(i)]))
    
num8 = np.array(num8)
num9 = np.array(num9)

def findProbability(n):
    makhrage8 = 1
    makhrage9 = 1
    for i in range(784):
        makhrage8 = makhrage8 * ((num8[i])** df['pixel'+str(i)][n]) * ((1-num8[i])**(1-df['pixel'+str(i)][n]))
        makhrage9 = makhrage9 * ((num9[i])** df['pixel'+str(i)][n]) * ((1-num9[i])**(1-df['pixel'+str(i)][n]))
    makhrage = makhrage9*PLABEL9 + makhrage8*PLABEL8
    return {
        'label8' : (makhrage8*PLABEL8)/makhrage,
        'label9' : (makhrage9*PLABEL9)/makhrage
    }
Probability201 = findProbability(200)
Probability202 = findProbability(201)
print('p(label = 8 | x = 201) : ' , Probability201['label8'])
print('p(label = 9 | x = 201) : ' , Probability201['label9'])
print('p(label = 8 | x = 202) : ' , Probability202['label8'])
print('p(label = 9 | x = 202) : ' , Probability202['label9'])