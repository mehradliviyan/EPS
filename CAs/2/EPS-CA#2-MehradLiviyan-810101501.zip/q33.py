import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
CHOSEN = 26
CHOSEN2 = 126
RESHAPESIZE = 28
file = pd.read_csv('./digits.csv')
num201 = file.iloc[200]
num202 = file.iloc[201]
file.drop([200 , 201] , axis=0 , inplace=True)
print(file)
label = pd.DataFrame(file['label'])
file[file < 128] = 0
file[file >= 128] = 1
file.drop(['label'] , axis=1 , inplace=True)
print(file)
# file['label'] = label
num = np.array(file.iloc[CHOSEN]).reshape(RESHAPESIZE , RESHAPESIZE)
num2 = np.array(file.iloc[CHOSEN2]).reshape(RESHAPESIZE , RESHAPESIZE)
plt.imshow(num)
plt.show() 
plt.imshow(num2)
plt.show()