import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

file = pd.read_csv('./digits.csv')
num201 = file.iloc[200]
num202 = file.iloc[201]
print('before delete : ')
print(file)
print( 'num201 : ' ,num201)
print( 'num202 : ' ,num202)
file.drop([200 , 201] , axis=0 , inplace=True)
print('after delete :')
print(file)