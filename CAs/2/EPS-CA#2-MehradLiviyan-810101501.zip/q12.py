import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

file = pd.read_csv('./Tarbiat.csv')
LISTOFMETRO = np.array(file['metro'])
LISTOFBRT = np.array(file['BRT'])
plt.hist(LISTOFMETRO , color='red')
plt.show()
plt.hist(LISTOFBRT , color='blue')
plt.show()
print('metro mean:'  , np.mean(LISTOFMETRO))
print('BRT mean:'  , np.mean(LISTOFBRT))