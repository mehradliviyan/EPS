import pandas as pd
import numpy as np

df = pd.read_csv('digits.csv')
num201 = df.iloc[200]
num202 = df.iloc[201]
df.drop([200 , 201] , axis=0 , inplace=True)
label = pd.DataFrame(df['label'])
df[df < 128] = 0
df[df >= 128] = 1
df['label'] = label
num8 = []
num9 = []
for i in range(784):
    num8.append(np.mean(df.loc[df['label'] == 8]['pixel' + str(i)]))
    num9.append(np.mean(df.loc[df['label'] == 9]['pixel' + str(i)]))
    
print('array for label 8 : ' ,num8)
print('array for label 9 : ' ,num9)