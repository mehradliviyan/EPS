import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

file = pd.read_csv('./digits.csv')
num201 = file.iloc[200]
num202 = file.iloc[201]
file.drop([200 , 201] , axis=0 , inplace=True)
print(file)
label = pd.DataFrame(file['label'])
file[file < 128] = 0
file[file >= 128] = 1
file['label'] = label
print(file.iloc[0])
print(file)