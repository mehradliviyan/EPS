import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import binom
METROLANDA = 3.516
BRTLANDA = 2.0636
PROBABILITY = METROLANDA/(METROLANDA + BRTLANDA)
N = 8
XRANGE = np.array(range(N+1))
yRange = np.array([binom.pmf(x ,N ,PROBABILITY , loc = 0) for x in XRANGE])
plt.plot(XRANGE , yRange , color='red')
plt.show()