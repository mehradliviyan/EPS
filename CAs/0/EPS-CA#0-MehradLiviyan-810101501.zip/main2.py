import numpy as np
import pandas as pn
import hazm as hz
import math
normalizer = hz.Normalizer().normalize
tokenizer = hz.WordTokenizer().tokenize
lemmatizerHZ = hz.Lemmatizer().lemmatize
stemmerHz = hz.Stemmer().stem
stopWords = hz.stopwords_list()
extraThings = [',', '.', ')', '(', ':', '«', '،', '»','؟', '،', '؛', '؟', 'ـ', '٪', '٫', '٬', '-', '…', '.']
stopWordsDic = {key: '' for key in (stopWords + extraThings)}
numbers = {'۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '۰', '۰', '۸', '۷', '۶','۵', '۴', '۳', '۲', '۱', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'}
def selectAllWords(arrayList):
    allWords = []
    for item in arrayList:
        allWords.extend(item)
    return list(set(allWords))


def deleteExtraWordsAndChars(arrayList):
    return [item for item in arrayList if stopWordsDic.get(item , 'not in dict') == 'not in dict']


def deleteNumbers(arrayList):
    return ''.join([item for item in arrayList if item not in numbers])


def makeBOW(file):
    allWords = selectAllWords(file['description'])
    littleChance = 0.0
    fileDict = {
        'رمان': [littleChance for word in allWords], 'داستان کوتاه': [littleChance for word in allWords], 'کلیات اسلام': [littleChance for word in allWords], 'داستان کودک و نوجوانان': [littleChance for word in allWords], 'جامعه‌شناسی': [littleChance for word in allWords], 'مدیریت و کسب و کار': [littleChance for word in allWords]
    }
    result = pn.DataFrame(fileDict, allWords)
    for index, row in file.iterrows():
        for item in row['description']:
            result[row['categories']][item] = result[row['categories']][item] + 1
    return result


def addTitleToDescription(file):
    for item, row in file.iterrows():
        row['description'] = row['title'] + row['description']


def calculateResult(trainFile, testFile):
    preConditionChance = 0.0
    result = {
        'رمان': [preConditionChance for word in testFile["title"]], 'داستان کوتاه': [preConditionChance for word in testFile['title']], 'کلیات اسلام': [preConditionChance for word in testFile['title']], 'داستان کودک و نوجوانان': [preConditionChance for word in testFile['title']], 'جامعه‌شناسی': [preConditionChance for word in testFile['title']], 'مدیریت و کسب و کار': [preConditionChance for word in testFile['title']]
    }
    result = pn.DataFrame(result, testFile['title'])
    pDic = calculateProbabilityCatgory(trainFile)
    for index, row in testFile.iterrows():
        wordsInRow = row['description']
        for title in trainFile.columns:
            result[title][row['title']] = calculteProbabilityForAcatgory(
                wordsInRow, trainFile, title, pDic[title])
    return (result)


def calculateProbabilityCatgory(BOW):
    pDic = {}
    for title in BOW.columns:
        pDic[title] = findChanceOfATitle(title)
    return pDic


def calculteProbabilityForAcatgory(wordsInRowToCheck, BOW, title, catgoryProbability):
    sum = 0
    littleChance = 0.001
    notInBOW = 0
    for item in wordsInRowToCheck:
        if item in BOW[title]:
            sum = sum + math.log10((BOW[title][item] + littleChance) /
                                   (BOW[title].sum()+littleChance*len(wordsInRowToCheck)))
        else:
            sum = sum + math.log10((notInBOW + littleChance) /
                                   (BOW[title].sum() + littleChance*len(wordsInRowToCheck)))
        sum = sum + math.log10(catgoryProbability)
    return sum


def findBestChoice(result):
    bestResults = []
    for key, row in result.iterrows():
        min = -10000000000000000000
        for item in row:
            if item > min:
                min = item
        bestResults.append(result.columns[result.eq(min).any()][0])
    return bestResults


def lemmatizer(arrayList):
    result = []
    for item in arrayList:
        result.append(lemmatizerHZ(item))
    return result


def stemmerize(arrayList):
    result = []
    for item in arrayList:
        result.append(stemmerHz(item))
    return result


def findChanceOfATitle(title):
    count = 0
    line = 0
    trainFile = pn.read_csv('books_train.csv')
    for key, row in trainFile.iterrows():
        if row['categories'] == title:
            count = count + 1
        line = line + 1
    return count/line


def doPreProcess(fileName):
    file = pn.read_csv(fileName)
    addTitleToDescription(file)
    file['description'] = file['description'].apply(normalizer)
    file['description'] = file['description'].apply(deleteNumbers)
    file['description'] = file['description'].apply(tokenizer)
    file['description'] = file['description'].apply(deleteExtraWordsAndChars)
    #file['description'] = file['description'].apply(lemmatizer)
    file['description'] = file['description'].apply(stemmerize)
    return file


def preprocces():
    return [doPreProcess('books_train.csv'), doPreProcess('books_test.csv')]


def procces(trainFile, testFile):
    BagOfWords = makeBOW(trainFile)
    print(BagOfWords)
    result = calculateResult(BagOfWords, testFile)
    bestResults = findBestChoice(result)
    result['بهترین انتخاب'] = bestResults
    return result


def printOutput(result, testFile):
    accurnece = 0
    for key, row in testFile.iterrows():
        if (row['categories'] == result.iloc[key, 6]):
            accurnece = accurnece + 1

    print('دقت : ' + str(accurnece/len(testFile['title'])))
    print(result)


def main():
    trainFile, testFile = preprocces()
    result = procces(trainFile, testFile)
    printOutput(result, testFile)
    return


main()
